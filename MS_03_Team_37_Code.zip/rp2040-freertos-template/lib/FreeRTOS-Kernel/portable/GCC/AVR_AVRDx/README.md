This port has been moved to `portable/ThirdParty/Partner-Supported-Ports/GCC/AVR_AVRDx` directory.
